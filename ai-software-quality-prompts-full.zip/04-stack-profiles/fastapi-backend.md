# FastAPI Backend Stack Profile
(Short description; full rules in previous messages.)
