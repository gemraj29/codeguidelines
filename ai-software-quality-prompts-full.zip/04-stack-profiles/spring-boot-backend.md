# Spring Boot Backend Stack Profile
