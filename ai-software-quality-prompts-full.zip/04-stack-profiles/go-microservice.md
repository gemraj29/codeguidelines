# Go Microservice Stack Profile
