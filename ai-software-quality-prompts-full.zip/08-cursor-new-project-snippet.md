# 08 – Cursor New Project Snippet

Use this JSON in `.cursorrules` for new projects to enforce your rules automatically.
