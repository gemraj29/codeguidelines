# 11 – Obsidian New Project Template

Use this in Obsidian to create a new note for each project, including your master prompt and pre-flight checklist.
