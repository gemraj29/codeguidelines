# 12 – VS Code Project Template

Save this as `project-template.md` in new repos to remind yourself which prompt to start with and which rules apply.
