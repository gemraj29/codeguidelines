# 03 – Start New Software Project – Mega Prompt

Use this as a template when starting a new project with any LLM.

- Assume the Universal Core Prompt rules apply.
- Ask clarifying questions first.
- Propose architecture (layers, modules, directory structure).
- Only then start coding with tests.

(You can paste the full version from here into your chat and fill in project details.)
