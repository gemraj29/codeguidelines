# 10 – Gemini / OpenAI System Instruction

Paste this into custom/system instructions for Gemini or ChatGPT so they always use your engineering standards.
