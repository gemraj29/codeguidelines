# FastAPI + React + ML Template (Prompt-Driven)

This is a skeleton repo prepared for:
- FastAPI backend
- React + TypeScript frontend
- ML/AI pipeline

Use together with the AI Software Quality Prompts pack:
- See `readmeprompt.md` for how to drive an LLM to fill this out.
